for i in range(99,0,-1):
  mcf = open('result.mcfunction', mode = 'w+', encoding = 'utf-8')
  mcf.write(str(i-1))
  mcf.close()