items_map = {
    "written_book": [
    "chest"
  ],
  "carrot_on_a_stick": [
    "fly",
    "forward",
    "backward",
    "through",
    "top",
    "surface",
    "random",
    "the_nether",
    "the_end",
    "history",
    "undo",
    "point",
    "world_spawn",
    "spawn",
    "death",
    "settings"
  ],
  "writable_book": [
    "add_a_point",
    "modify_the_point"
  ]
}

item_template = {
  "model": {
    "type": "minecraft:model",
    "model": None
  }
}