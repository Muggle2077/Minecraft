from pathlib import Path
import json

lang_files = ['zh_cn.json', 'en_us.json']
lang_dir = 'assets/teleport/lang'

lang_paths = [Path('.') / lang_dir / lang_file for lang_file in lang_files]

lang_data = {}
for path in lang_paths:
    with open(path, mode='r', encoding='utf-8') as f:
        lang_data[path.name] = json.load(f)

for lang_name, lang_values in lang_data.items():
    other_langs = {k: v for k, v in lang_data.items() if k != lang_name}
    unique_keys = set(lang_values.keys())
    
    for other_name, other_values in other_langs.items():
        unique_keys -= set(other_values.keys())
    
    if not unique_keys:
        unique_keys = '没有'
    
    print(f"\n只在 {lang_name} 里:\n  {unique_keys}")

print('')