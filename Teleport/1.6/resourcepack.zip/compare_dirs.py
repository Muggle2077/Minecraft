from pathlib import Path

dirs = [
    Path('.') / 'assets/teleport/items',
    Path('.') / 'assets/teleport/models'
]

def find_unique_elements(sets: list[set[Path]]) -> list[set[Path]]:
    unique_sets = []
    for i, current_set in enumerate(sets):
        other_sets_union = set().union(*[s for j, s in enumerate(sets) if j != i])
        unique_set = current_set - other_sets_union
        unique_sets.append(unique_set)
    return unique_sets

def get_files(dir_path: Path):
    path = Path(dir_path)
    return {file.relative_to(path) for file in path.rglob('*')}

def get_diff(dirs: list[Path]):
    return find_unique_elements([get_files(each_dir) for each_dir in dirs])

only_ins = get_diff(dirs)

for index, only_in in enumerate(only_ins):
    if only_in == set(): only_in.add('没有任何文件或文件夹！')
    print(f'\n只在 {dirs[index]} 中：', *only_in, sep="\n  ")
print('')