from pathlib import Path
import json
from all_data import items_map, item_template as template

items_dir = Path('.') / 'assets/teleport/items'
for item_type, item_ids in items_map.items():
    for item_id in item_ids:
        item_path = items_dir / f'{item_id}.json'
        with open(item_path,encoding='utf-8',mode='w+') as f:
            template['model']['model'] = f'teleport:{item_id}'
            json.dump(template, f, indent=2, ensure_ascii=False)