from pathlib import Path
import json

font_name = '12.json'
font_dir = 'assets/teleport/font'

font_path = Path('.') / font_dir / font_name

with open(font_path,encoding='utf-8',mode='r+') as font_file:
    font_dict = json.load(font_file)
    sorted_providers = sorted(font_dict['providers'], key=lambda x: x['file'])
    font_dict['providers'] = sorted_providers
    font_file.seek(0)
    json.dump(font_dict, font_file, indent=2, ensure_ascii=False)
    font_file.truncate()

print(f'已排序 {font_name}')