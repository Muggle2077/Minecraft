from pathlib import Path
import json

lang_dir = Path(".") / "assets/teleport/lang"
lang_names = ("en_us.json", "zh_cn.json")

for lang_name in lang_names:
    lang_path = lang_dir / lang_name
    with open(lang_path, encoding="utf-8", mode="r+") as lang_file:
        lang_dict = json.load(lang_file)
        sorted_lang_dict = dict(sorted(lang_dict.items()))
        lang_file.seek(0)
        json.dump(sorted_lang_dict, lang_file, indent=2, ensure_ascii=False)
        lang_file.truncate()
    print(f"已排序 {lang_path}")