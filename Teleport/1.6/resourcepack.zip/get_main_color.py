from pathlib import Path
from colorthief import ColorThief
from PIL import Image

main_color_from_path = Path('.') / 'assets/teleport/textures/item/chest.png'
main_color_saved_path = Path('.') / 'main_color.png'

thief = ColorThief(main_color_from_path)
palette = thief.get_palette()
print(palette)

color_image = Image.new('RGB', (len(palette), 1))
color_image.putdata(palette)
color_image.save(main_color_saved_path)