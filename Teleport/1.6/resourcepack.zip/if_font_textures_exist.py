from pathlib import Path
import json

font_name = '16.json'
font_dir = 'assets/teleport/font'

font_path = Path('.') / font_dir / font_name

not_exist_count = 0
with open(font_path,encoding='utf-8',mode='r+') as font_file:
    font_dict = json.load(font_file)
for provider in font_dict['providers']:
    namespace_path = provider['file']
    parts = namespace_path.split(":", 1)
    real_path = Path('.') / f'assets/{parts[0]}/textures/{parts[1]}'
    if not real_path.exists():
        print(f'不存在 {real_path}')
        not_exist_count += 1

print(f'在 {font_path} 中有 {not_exist_count} 个不存在')