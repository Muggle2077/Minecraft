from pathlib import Path
from all_data import items_map

function_name = "item.mcfunction"
function_dir = "data/teleport/function"

loot_give_path = Path(".") / function_dir / function_name

commands = []
for item_type, item_ids in items_map.items():
    for item_id in item_ids:
        commands.append(f"loot give @s loot teleport:{item_id}")

with open(loot_give_path, encoding="utf-8", mode="w+") as loot_give_file:
    loot_give_file.write("\n".join(commands))

print(f"已生成 {loot_give_path}")
