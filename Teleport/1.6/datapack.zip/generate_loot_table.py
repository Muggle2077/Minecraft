from pathlib import Path
import json
from all_data import items_map, loot_table_template as template

loot_table_dir = "data/teleport/loot_table"

skips = ["chest"]

for item_type, item_ids in items_map.items():
    for item_id in item_ids:
        if item_id in skips:
            continue
        with open(
            Path(".") / loot_table_dir / f"{item_id}.json", encoding="utf-8", mode="w+"
        ) as loot_table_file:
            template["pools"][0]["entries"][0]["name"] = "minecraft:" + item_type
            template["pools"][0]["entries"][0]["functions"][0]["components"][
                "minecraft:custom_data"
            ]["teleport"] = item_id
            template["pools"][0]["entries"][0]["functions"][0]["components"][
                "minecraft:item_name"
            ] = {"translate": f"teleport.{item_id}"}
            template["pools"][0]["entries"][0]["functions"][0]["components"][
                "minecraft:item_model"
            ] = ("teleport:" + item_id)
            json.dump(template, loot_table_file, indent=2, ensure_ascii=False)
