import os
from colorthief import ColorThief
from PIL import Image

dir_name = os.path.dirname(__file__)
# path
input_path = os.path.join(dir_name, 'speed_icon.png')
# get
thief = ColorThief(input_path)
palette = thief.get_palette()
# paint
output_image = Image.new('RGB', (len(palette), 1))
output_image.putdata(palette)
# show
print(palette)
output_image.show()
