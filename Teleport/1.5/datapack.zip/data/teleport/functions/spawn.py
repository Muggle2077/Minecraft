import os

output_dir = os.path.join(os.path.dirname(__file__),'jump_boost')

if not os.path.exists(output_dir): os.mkdir(output_dir)

levels = ['I','II','III','IV','V','VI','VII','VIII','IX','X','XI','XII','XIII','XIV','XV','XVI']

with open('0.mcfunction',mode='w+',encoding='utf-8') as output_file:
  output_text = f'''effect clear @s minecraft:jump_boost
title @s actionbar [{{"translate":"effect.minecraft.jump_boost"}}," O"]'''
  output_file.write(output_text)

for i in range(1,16):
  with open(os.path.join(output_dir,hex(i)[2:]+'.mcfunction'),mode='w+',encoding='utf-8') as output_file:
    output_text = f'''effect clear @s minecraft:jump_boost
effect give @a minecraft:jump_boost 1000000 {i-1} true
title @s actionbar [{{"translate":"effect.minecraft.jump_boost"}}," {levels[i-1]}"]'''
    output_file.write(output_text)