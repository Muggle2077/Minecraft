# 统计配方书的数量
execute store result score #count muggle run clear @s minecraft:knowledge_book
# 按数量将配方书替换为石镐
execute if score #count muggle matches 1.. run function muggle:knowledge_book
# 移除石镐配方
recipe take @s muggle:stone_pickaxe
# 移除进度
advancement revoke @s only muggle:stone_pickaxe