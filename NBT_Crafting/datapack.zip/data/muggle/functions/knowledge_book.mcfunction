# 配方书数量 -1
scoreboard players remove #count muggle 1
# 石镐数量 +1
give @s minecraft:stone_pickaxe{Enchantments:[{id:"minecraft:sharpness",lvl:1s}]} 1
# 如果还有配方书，重复上述命令
execute if score #count muggle matches 1.. run function muggle:knowledge_book