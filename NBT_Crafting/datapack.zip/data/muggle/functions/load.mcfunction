# 记分板用于存储配方书的数量
scoreboard objectives add muggle dummy