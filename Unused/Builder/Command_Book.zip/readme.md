# Command Book
- 数据包，允许玩家绕过不允许作弊的限制来运行命令。
- 在书与笔的第一页写好命令，在第二页写上 `cb`，完成后丢出。
  - 例子：`/give @s minecraft:writable_book{pages:["summon zombie ~ ~ ~","cb"]}`
- 原理：将书与笔第1页的内容复制到在当前位置放置的保持开启的命令方块。在命令被执行后清除命令方块。